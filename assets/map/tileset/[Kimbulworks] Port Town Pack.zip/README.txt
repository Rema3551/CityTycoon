Hi, Kimbulworks here!
Thank you for downloading these assets.

License: The assets contained within this pack can be used for both free and commercial projects.
You are NOT permitted to resell, sublicense, or distribute assets to third parties as standalone files.
Feel free to modify or change any of the assets to fit your creative needs.
Credit is not required, but greatly appreciated.
In case you want to offer me credits, please use my current username (Kimbulworks).

If you are interested in my art style,
kindly follow and rate this pack to support the growth of this account.

Check out other assets at https://kimbulworks.itch.io/

Thank you!