<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Objects_Rocks" tilewidth="28" tileheight="30" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="28" height="14" source="../../Art/Rocks/Rock_Brown_1.png"/>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0" y="14">
    <polygon points="0,0 28,0 28,-5 0,-5"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="1">
  <image width="15" height="30" source="../../Art/Rocks/Rock_Brown_2.png"/>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0625" y="25.875">
    <polygon points="0,0 4,4.125 9.625,4.25 15,-1.125 15.125,-5.875 0,-6"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="2">
  <image width="27" height="27" source="../../Art/Rocks/Rock_Brown_4.png"/>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.0625" y="20.5">
    <polygon points="0,0 2.375,3 4.125,3.5 9.125,3.5 9.125,5 12,6.5 18.625,6.75 22.75,4.625 24.25,1 27.125,-2.375 27.25,-6.125 6.375,-6.375 0.375,-3.5"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="3">
  <image width="14" height="14" source="../../Art/Rocks/Rock_Brown_6.png"/>
  <objectgroup draworder="index" id="2">
   <object id="1" x="-0.3125" y="10.875">
    <polygon points="0,0 2.75,3.125 11.25,3.125 14.25,0.875 14.375,-1.25 11.75,-2.75 2.625,-2.875"/>
   </object>
  </objectgroup>
 </tile>
 <tile id="4">
  <image width="9" height="12" source="../../Art/Rocks/Rock_Brown_9.png"/>
  <objectgroup draworder="index" id="2">
   <object id="1" x="0.125" y="10">
    <polygon points="0,0 1.75,2.0625 5.875,2 8.8125,0.3125 8.9375,-1.8125 7.3125,-3 1.5625,-2.8125 -0.0625,-1.5"/>
   </object>
  </objectgroup>
 </tile>
</tileset>
